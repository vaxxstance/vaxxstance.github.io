"""
vaxxstance 2021 evaluation script. It implements the evaluation method
from Stance Detection in Twitter, SemEval 2016.
Contact: rodrigo.agerri@ehu.eus
"""
import argparse
import csv
import sys
from sklearn.metrics import classification_report
from sklearn.metrics import precision_recall_fscore_support

# prediction map
label_map = {'AGAINST': 0,
             'FAVOR': 1,
             'NONE': 2}

target_names = ['AGAINST', 'FAVOR', 'NONE']


def load_csv(infile):
    """processing the gold and pred files"""
    id_stance = {}
    csvfile = open(infile)
    csv_file_reader = csv.reader(csvfile, delimiter=',', quotechar='"')
    # csv_file_reader = csv.reader(csvfile, delimiter='\t')
    for row in csv_file_reader:
        if row[3] in target_names:
            id_stance[row[0]] = label_map[row[3]]
            # id_stance[row[0]] = label_map[row[1]]
    return id_stance


def main():
    """main function"""
    parser = argparse.ArgumentParser(description="Evaluation script for VaxxStance 2021; it reproduces the metrics implemented for the Stance Detection in Twitter task at SemEval 2016")
    parser.add_argument('--gold', default=sys.stdin.fileno(), help="The gold standard test data")
    parser.add_argument('--preds', default=sys.stdin.fileno(), help="The prediction over the test data")
    parser.add_argument('--encoding', default='utf-8', help="The encoding for input/output, it defaults to utf-8")
    args = parser.parse_args()

    y_true = load_csv(args.gold)
    y_pred = load_csv(args.preds)

    print("\n")
    print("====================")
    print("TEST and PRED FILES")
    print("====================")
    print(f"TEST: {args.gold} : ", len(y_pred))
    print(f"PRED: {args.preds}: ", len(y_true))
    print("~~\n")
    l_true = []
    l_pred = []

    for tweet_id in y_true.keys():
        l_true.append(y_true[tweet_id])
        l_pred.append(y_pred[tweet_id])

    if len(y_pred) == len(y_true):
        print(classification_report(l_true, l_pred, target_names=target_names))
        prec, recall, f_score, _ = precision_recall_fscore_support(l_true, l_pred, average=None)
        print("==============")
        print("Overall Result")
        print("==============")
        print(f"AGAINST\tprecision:{prec[0]:.4f} recall:{recall[0]:.4f} f1-score:{f_score[0]:.4f}")
        print(f"FAVOR\tprecision:{prec[1]:.4f} recall:{recall[1]:.4f} f1-score:{f_score[1]:.4f}")
        print("--------------")
        print(f"Macro F1: {(f_score[0]+f_score[1])/2:.4f}")
        print("\n")


if __name__ == '__main__':
    main()
