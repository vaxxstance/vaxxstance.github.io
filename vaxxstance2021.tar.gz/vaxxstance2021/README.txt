********************************************************************************************
* VaxxStance / Going Beyond Text in Crosslingual Stance Detection @ IberLEF 2021 Training Data
*
* https://vaxxstance.github.io/
*
* Task organizers:
*
* Contact: https://github.com/vaxxstance/vaxxstance.github.io/discussions
*
* Citation: Rodrigo Agerri, Roberto Centeno, María Espinosa, Joseba Fernandez
* de Landa, Alvaro Rodrigo (2021). VaxxStance@IberLEF 2021: Going Beyond Text
* in Crosslingual Stance Detection. Proceedings of the Iberian Languages
* Evaluation Forum (IberLEF 2021), CEUR Workshop Proceedings, 2021.
*
********************************************************************************************

A single development set will be provided (training data), and authors are
encouraged to create their own partitions or experiment by means of
cross-validation in order to develop their systems.

## Textual Data

+ Basque eu_train.csv: 1070 tweets written by 149 users (219 AGAINST, 327 FAVOR and 524 NONE)
+ Spanish es_train.csv: 2003 tweets written by 1261 users (475 AGAINST, 937 FAVOR and 591 NONE)
+ Basque eu_test.csv: 313 tweets written by 62 users (92 AGAINST, 85 FAVOR and 135 NONE)
+ Spanish es_test.csv: 694 tweets written by 415 users (140 AGAINST, 359 FAVOR and 195 NONE)


The data format for the train and test textual data is the following:

tweet_id user_id text label

where 

+ tweet_id: the Twitter ID of the message
+ user_id: the Twitter ID of the user who posted the message
+ text: the content of the message
+ label: AGAINST, FAVOR or NONE

## Contextual Data

In addition to the tweets themselves, we also provide the following contextual information
about the users contained in the training data and their social interactions (retweets, friends, etc.)

### user_train.csv files (one per language)

user_id statuses_count followers_count friends_count listed_count created_at emoji

where user_id is the Twitter ID of the user who posted the message, statuses_count,
friends_count indicates the number of friends of the user, followers_count indicates
the number of followers of the user, created_at displays the time of the user registration
on Twitter, and emoji shows a list of the emojis in the user’s bio (if present, otherwise
the field is left empty).

### tweet_train.csv (one per language)

tweet_id user_id retweet_count favorite_count source created_at

where tweet_id is the Twitter ID of the message, user_id is the Twitter ID of the user
who posted the message, retweet_count indicates the number of times the tweet has
been retweeted, favorite_count indicates the number of times the tweet has been liked,
source indicates the type of posting source (e.g. iOS or Android), and created_at dis-
plays the time of creation according to a yyyy-mm-dd hh:mm:ss format. 
		
### retweet_train.csv (one per language)

Source Target Weight

where Source and Target indicate two nodes of a social interaction between two Twitter
users. More specifically, the source user performs one of the considered social relation
towards the target user. Two users are tied by a retweet relationship if
the source user retweeted the target user.

Weight indicates the number of interactions existing between two users.

#### eu_retweet_timeline_train.csv

Same structure as retweet_train.csv but in this case we collect all the
retweets from the timelines of the users contained in the training set. This is
only done for Basque because the low number of retweets of the tweets contained
in the training data.

### friend_train.csv

Source Target 

Two users are tied by a friend relationship if the source user follows the target user. 

